# M云音乐

#### 介绍
仿网易云音乐，完成了页面功能和音乐播放。
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142622_66737608_5272006.png "截屏2020-03-12下午2.05.48.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142648_67bcf888_5272006.png "截屏2020-03-12下午2.05.55.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142702_c83255d9_5272006.png "截屏2020-03-12下午2.06.11.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142724_c962192f_5272006.png "截屏2020-03-12下午2.06.20.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142752_91587d1f_5272006.png "截屏2020-03-12下午2.06.34.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142808_94ab8645_5272006.png "截屏2020-03-12下午2.06.42.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142914_9fcb8316_5272006.png "截屏2020-03-12下午2.06.52.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/0312/142924_6c087a07_5272006.png "截屏2020-03-12下午2.21.44.png")



#### 软件架构
基于uni-app 快速开发的网易云音乐


#### 安装教程

1.  本App 已打包安卓 下载体验地址： https://www.lanzous.com/ia6atdi


#### 使用说明

1.  git clone https://gitee.com/lit_bear/m_cloud_music.git
2.  HBuilderX 打开项目
3.  开始你的创作吧





