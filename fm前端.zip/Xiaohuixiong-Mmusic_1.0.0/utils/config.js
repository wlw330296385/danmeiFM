const config = {
	/*
	 * 接口地址
	 */
	serverUrl: {
		dev: 'http://bq77.net.cn',
		pro: 'http://bq77.net.cn'
	},
	fileUrl: {
		dev: '',
		pro: ''
	},
	uploadUrl: {
		dev: '',
		pro: ''
	},
	websocket: {
	    dev: '',
	    pro: ''
	}
};

export default config;
