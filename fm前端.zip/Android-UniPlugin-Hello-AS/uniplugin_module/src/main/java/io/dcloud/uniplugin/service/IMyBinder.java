package io.dcloud.uniplugin.service;

import android.app.Activity;

public interface IMyBinder {

  void callMethodOfService();

  void setActivity(Activity activity);
}
