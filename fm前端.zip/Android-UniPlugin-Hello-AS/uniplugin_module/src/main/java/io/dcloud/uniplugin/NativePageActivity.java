package io.dcloud.uniplugin;

import android.app.Activity;
import android.os.Bundle;

public class NativePageActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
