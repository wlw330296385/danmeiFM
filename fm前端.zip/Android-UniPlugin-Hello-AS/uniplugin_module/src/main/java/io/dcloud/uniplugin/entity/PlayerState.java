package io.dcloud.uniplugin.entity;

public enum PlayerState {
    NONE, IDLE, INITIALIZED, PREPARING, PREPARED, STARTED, STOPPED, PAUSED, PLAYBACK_COMPLETED, END, ERROR
}
